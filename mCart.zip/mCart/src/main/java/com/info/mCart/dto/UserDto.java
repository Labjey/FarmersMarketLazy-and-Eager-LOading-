package com.info.mCart.dto;

import org.springframework.data.jpa.repository.JpaRepository;


import com.info.mCart.entity.Users;

public interface UserDto extends JpaRepository<Users, Integer>{

}
