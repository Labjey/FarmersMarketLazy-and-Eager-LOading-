package com.info.mCart.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Orders")
public class Order implements Serializable {
	
	
	    private static final long serialVersionUID = -2576670215015463100L;
	 
	    @Id
	    @Column(name = "orderId", length = 50)
	    private String orderId;
	 
	    @Column(name = "cartID", nullable = false)
	    private double cartID;
	    
	    
	    public String getOrderId() {
			return orderId;
		}



		public void setOrderId(String orderId) {
			this.orderId = orderId;
		}



		public double getCartID() {
			return cartID;
		}



		public void setCartID(double cartID) {
			this.cartID = cartID;
		}



		public Date getDateOfOrder() {
			return dateOfOrder;
		}



		public void setDateOfOrder(Date dateOfOrder) {
			this.dateOfOrder = dateOfOrder;
		}



		public double getOrderAmount() {
			return orderAmount;
		}



		public void setOrderAmount(double orderAmount) {
			this.orderAmount = orderAmount;
		}



		public String getProductsInOrder() {
			return productsInOrder;
		}



		public void setProductsInOrder(String productsInOrder) {
			this.productsInOrder = productsInOrder;
		}



		@Column(name = "dateOfOrder", nullable = false)
	    private Date dateOfOrder;
	 
	   
	    @Column(name = "orderAmount", nullable = false)
	    private double orderAmount;
	 
	
	 
	    @Column(name = "productsInOrder", length = 128, nullable = false)
	    private String productsInOrder;

	    
}
