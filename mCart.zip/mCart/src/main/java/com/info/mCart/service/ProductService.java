package com.info.mCart.service;



import org.springframework.beans.factory.annotation.Autowired;

import com.info.mCart.dto.ProductDto;
import com.info.mCart.entity.*;

public class ProductService {
	
	@Autowired
	private ProductDto productDto;
	
	public java.util.List<Products> getProducts() {
		
		return productDto.findAll();
	}

	
	
}
