package com.info.mCart.entity;


import java.awt.List;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Cart")
public class Cart {
	
	private static final long serialVersionUID = -2576670215015463100L;
	 
    @Id
    @Column(name = "orderId", length = 50)
    private int cartId;
    
    @Column(name= "username")
    private  String username;
    
    @Column(name="dateOfCration")
    private Date dateOfCration;
    
    @Column(name="dateOfModification")
    private Date dateOfModification;
    
    @Column(name="statusOfCart")
    private String statusOfCart;
    
    @Column(name="product")
    private ArrayList<Products> product;

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Date getDateOfCration() {
		return dateOfCration;
	}

	public void setDateOfCration(Date dateOfCration) {
		this.dateOfCration = dateOfCration;
	}

	public Date getDateOfModification() {
		return dateOfModification;
	}

	public void setDateOfModification(Date dateOfModification) {
		this.dateOfModification = dateOfModification;
	}

	public String getStatusOfCart() {
		return statusOfCart;
	}

	public void setStatusOfCart(String statusOfCart) {
		this.statusOfCart = statusOfCart;
	}

	public ArrayList<Products> getProduct() {
		return product;
	}

	public void setProduct(ArrayList<Products> product) {
		this.product = product;
	}
    
    
    
}
