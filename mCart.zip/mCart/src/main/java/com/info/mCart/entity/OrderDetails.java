package com.info.mCart.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="orderDetails")
public class OrderDetails {

}
