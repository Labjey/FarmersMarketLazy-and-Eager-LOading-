package com.info.mCart.dto;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.Repository;

import com.info.mCart.entity.Cart;


public interface CartDto extends JpaRepository<Cart,Integer> {

}
