package com.info.mCart.dto;

import org.springframework.data.jpa.repository.JpaRepository;


import com.info.mCart.entity.Products;

public interface ProductDto extends JpaRepository<Products,Integer>{


	
}
