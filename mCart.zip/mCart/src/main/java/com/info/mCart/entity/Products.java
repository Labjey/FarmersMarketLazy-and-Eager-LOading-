package com.info.mCart.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="products")

public class Products implements Serializable{
	
	private static final long serialVersionUID = -1000119078147252957L;

	@Id
	@Column(name="productId"  )
	private int productId;
	
	@Column(name="productName")
	private String productName;
	
	@Column(name="productCode")
	private String productCode;
	
	@Column(name="Destcription")
	private String Description;
	
	@Column(name="imageUrl")
	private String imageUrl;
	
	@Column(name="manufacturer")
	private String manufacturer;
	
	@Column(name="price")
	private double price;
	
	@Column(name="rating")
	private double rating ;

	@Column(name="osType")
	private String osType;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getOsType() {
		return osType;
	}

	public void setOsType(String osType) {
		this.osType = osType;
	}
	
	
	
}
