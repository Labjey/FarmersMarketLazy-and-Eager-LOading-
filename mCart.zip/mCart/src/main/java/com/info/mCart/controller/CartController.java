package com.info.mCart.controller;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.info.mCart.service.CartService;
import com.info.mCart.service.ProductService;
import com.info.mCart.service.UserService;

@RestController
@RequestMapping("/carts")
public class CartController {
	
	
	
	private CartService cartService;
	private ProductService productService; 
	private UserService userService;
	
	
	@PutMapping(produces = "application/json ")
	public String addCart(@RequestParam("productId") int productId,
			                 @RequestParam("productName") String productName,
			                 @RequestParam("Quantity") int quantity
			                 ) {
		return "";
	}
	
	

}
