package com.info.mCart.dto;

import org.springframework.data.jpa.repository.JpaRepository;


import com.info.mCart.entity.Order;

public interface OrderDto extends JpaRepository<Order,Integer> {

}
